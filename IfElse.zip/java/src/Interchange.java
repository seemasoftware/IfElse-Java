import java.util.Scanner;

public class Interchange {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("First Value = ");
        int a = scanner.nextInt();

        System.out.print("Second Value = ");
        int b = scanner.nextInt();

        if (a == a) {System.out.println("Interchanged Value ="+b);}
            else {}
        if (b == b) {System.out.println("Interchanged Value ="+a);}
            else {}

        }

    }
